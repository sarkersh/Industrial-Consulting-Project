import React from "react";

const NotFound: React.FC = () => {
  return <div>NotFound</div>;
};

export default NotFound;
