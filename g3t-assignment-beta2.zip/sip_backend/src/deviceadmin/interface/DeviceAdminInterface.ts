interface DeviceAdminInterface {
    mac: number,
    admin_pass: string
}
export default DeviceAdminInterface;