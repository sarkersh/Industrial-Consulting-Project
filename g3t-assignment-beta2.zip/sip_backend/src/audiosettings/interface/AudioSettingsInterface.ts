interface AudioSettingsInterface {
    mac: number;
    fcodec: string;
    scodec: string;
    tcodec: string;
    handsetgain: number;
}
export default AudioSettingsInterface;