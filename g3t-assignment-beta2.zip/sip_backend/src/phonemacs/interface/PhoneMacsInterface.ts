interface PhoneMacsInterface {
    id        : number,
    model_id  : string,
    model_mac : string
}
export default PhoneMacsInterface;