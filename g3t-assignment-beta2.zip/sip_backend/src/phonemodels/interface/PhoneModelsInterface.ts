interface PhoneModelsInterface {
    id: number,
    phone_name: string,
    mp_keys: string,
    common: string
}
export default PhoneModelsInterface;