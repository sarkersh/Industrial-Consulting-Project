interface WebServicesInterface {
    mac                 : string,
    weather_update      : string
    currency_exchange   : string
    firmware_upgrade    : string
    connection_type     : number
}
export default WebServicesInterface;