interface SipServerInterface {
    id: number,
    sip_ip: string,
    server_type: string,
}
export default SipServerInterface;