interface UserInterface {
    id: Number;
    username: string;
    email: string;
    password: string;
}
export default UserInterface;