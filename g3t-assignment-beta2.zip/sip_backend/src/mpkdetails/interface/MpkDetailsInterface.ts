interface MpkDetailsInterface {
    id              : number,
    mac             : string,
    mode            : string
    account         : string
    mpk_description : string
    mpk_value       : string

}
export default MpkDetailsInterface;