interface Phone {
    id: number;
    number: string;
    type: string;
}

export { Phone };